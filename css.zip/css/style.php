/*home page styling start*/
body{
	overflow-x: hidden;
}
*{
	margin: 0;
	padding: 0;
	font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif
}
.topnav{
	background-color: #11B3DE;
	height: 72px;
}
.topnav a{
	float: right;
	color: azure;
	padding: 23px 30px;
	text-decoration: none;
    font-size: 18px;
	margin-right: 27px;
}
		
.topnav a:hover{
	background-color: white;
	color: #11B3DE;
}
		
.topnav a.active{
	background-color: white;
	color: white;
}
@media (max-width: 992px){
.topnav{	
	background-color: #11B3DE;
	height: 142px;
}
.topnav a{
	float: right;
	color: azure;
	padding: 23px 30px;
	text-decoration: none;
    font-size: 17px;
	margin-right: 10px;
}
		
.topnav a:hover{
	background-color: white;
	color: #11B3DE;
}
.Services .col-sm-4{
	margin-top: 3px;
	margin-left: 54px;
}
.videoGallery{
	margin-left: 82px;
}
.videoGallery .videoTxt{
	padding-right: 70px;
}
}
.topnav .LOGO{
	width: 140px;
	height: 60px;
	margin: 6px 18px;
}
.topnav .fa-user-circle{
	font-size: 30px;
	color: white;
	float: right;
	margin: 20px;
}
.topnav .fa-shopping-cart{
	font-size: 30px;
	color: white;
	float: right;
	margin: 20px -4px;
}
.topnav .fa-search{
	font-size: 28px;
	color: white;
	float: right;
	margin: 20px;
}
.topnav img{
	width: 160px;
	height: 60px;
}
/*start of banner section*/
.banner .carousel-inner img{
	width: 100%;
	height: 550px;
}
.banner .carousel-caption .btn-success{
	margin-bottom: 100px;
	border-radius: 35px;
}
.banner .carousel-caption .btn-success:focus{
	outline: none;
}

/*end of banner css*/
.Services .col-sm-4{
	margin-top: 3px;
} 
.Services h3{
	padding-top: 10px;
	font-weight: bold;
}
.Services .col-sm-4 img{
	margin-left: 80px;
}
.Services .col-sm-4 .seo{
	margin-left: 130px;
	font-weight: bold;
}
.Services .col-sm-4 .service{
	margin-left: 105px;
	font-weight: bold;
}
.Services .col-sm-4 .logo{
	margin-left: 130px;
	font-weight: bold;
}
.Services .col-sm-4 p{
	padding-left: 80px;
	font-size: 16px;
}
.videoGallery .videoScreen label{
	margin-top: 10px;
	font-size: 14px;
	height: 40px;
	background-color: #6ABF69;
}
.videoGallery iframe{
	width: 100%;
	height: 230px;
	margin-top: 10px;
	transition: width 2s, height 2s;
}
.videoGallery iframe:hover{
	   height: 285px;
}
.videoGallery h3{
	font-weight: bold;
	padding-top: 30px;
}
.videoGallery label{
	background-color: #E3331F;
	color: white;
	border-radius: 8px;
	width: 165px;
	font-size: 12px;
}
.videoGallery .videoScreen{
	border: 1px solid #D7DCD3;
	margin-top: 20px;
	margin-left: 10px;
	width: 274px;
}
.videoGallery .row{
	margin-bottom: 20px;
}
.videoGallery .videoScreen:hover{
	background-color: #D7DCD3;
}
.AboutUs .well-lg{
	background-color: #E6EAE2;
	margin-top: 20px;
}
.AboutUs .well-lg h2{
	font-weight: bold;
	padding-left: 17px;
}
.AboutUs .well-lg p{
	font-size: 17px;
	padding-left: 17px;
}
.review{
	margin-top: 40px;
}
.review .col-sm-3 .img-left{
	margin-top: 50px;
}

.review .col-sm-3 .img-right{
	float: right;
	margin-top: 50px;
}
.review .col-sm-2 .img-client{
	margin-right: 70px;
}
.review .col-sm-4 h2{
	text-align: center;
	font-weight: bold;
}
.review .col-sm-4 p{
	text-align: center;
}
.emailSec .well-lg{
	background-color: #11B3DE;
	height: 105px;
	margin-top: 60px;
}
.emailSec .well-lg form .email{
	width: 350px;
	height: 35px;
	text-indent: 10px;
	border-color: white;
	margin-top: 10px;
	border-radius: 15px;
}
.emailSec .well-lg form label{
	font-size: 18px;
	color: white;
	font-style: italic;
}
.emailSec .well-lg form .btn-lg{
	background-color: white;
	border-radius: 35px;
	color: #11B3DE;
	height: 35px;
	width: 110px;
	padding-bottom: 30px;
	font-size: 16px;
	margin-left: 140px;
	font-weight: bold;
}
.emailSec .well-lg form .btn-lg:focus{
	outline: none;
}
/*home page styling end*/

/*contact page styling start*/
.banner img{
	width: 100%;
	height: 540px;
}
.banner .carousel-caption .banner1Heading{
	font-weight: bold;
	margin-top: 30px;
}
.banner .carousel-caption .banner1Para{
	font-size: 17px;
	margin-bottom: 50px;
}
.banner .carousel-caption .banner2Heading{
	font-weight: bold;
}
.banner .carousel-caption .banner2Para{	
	padding-bottom: 170px;
	font-size: 17px;

}
.contact-form h4{
	text-align: center;
	margin-top: 30px;
	font-weight: bold;
}
.contact-form .jumbotron{
	margin-top: 30px;
	height: 880px;
}
.contact-form .jumbotron h2{
	text-align: center;
	font-weight: bold;
	color: black;
}
.contact-form .jumbotron form label{
	font-size: 16px;
	color: black;
	margin-top: 30px;
	margin-left: 20px;
}
.contact-form .jumbotron form .name{
	text-indent: 10px;
	margin-top: 10px;
	width: 350px;
	height: 35px;
	margin-left: 20px;
	border-color: white;
	border-radius: 10px;
}
.contact-form .jumbotron form .country{
		text-indent: 10px;
	margin-top: 10px;
	width: 350px;
	height: 35px;
	margin-left: 20px;
	border-color: white;
	border-radius: 10px;
}
.contact-form .jumbotron form .contact{
		text-indent: 10px;
	margin-top: 10px;
	width: 350px;
	height: 35px;
	margin-left: 20px;
	border-color: white;
	border-radius: 10px;
}
input:focus{
        outline: none;
    }
.contact-form .jumbotron form .email{
		text-indent: 10px;
	margin-top: 10px;
	width: 350px;
	height: 35px;
	margin-left: 20px;
	border-color: white;
	border-radius: 10px;
}
.contact-form .jumbotron form .comments{
		text-indent: 10px;
	margin-top: 10px;
	width: 350px;
	height: 200px;
	margin-left: 20px;
	border-color: white;
	padding-bottom: 160px;
	border-radius: 10px;
}
.contact-form .jumbotron form .btn-lg{
	margin-top: 20px;
	width: 100px;
	border-radius: 35px;
}
.contact-form .jumbotron form .btn-lg:focus{
	outline: none;
}
/*contact styling end*/

/*start of product page styling*/
.categories{
	margin-top: 40px;
}
.categories .categoriesHeading{
	text-align: center;
	font-weight: bold;
}
.my_panel > .panel-body {
  padding: 0px;
}
.my_panel > .panel-body:hover{
	background-color: #D7DCD3;
	flex: 1 1 auto;
    padding: 1.5rem 1.5rem;
}
.my_panel > .panel-body > img {
	margin-top: 20px;
  width: 80%;
  height: auto;
}

.my_panel > .panel-footer {
  text-align: center;
  font-weight: bold;
}
/* BestSeller Section Start*/
.productSec {
    padding: 20px 0;
}

.proBox {
    border: 1px solid #D7DCD3;
    border-radius: 0 30px;
    text-align: center;
    transition: 1s;
}
.proBox:hover {
    border: 1px solid #D7DCD3;
    box-shadow: 0 10px 10px rgba(0,0,0,0.3);
    transition: 1s;
}
.proBox img {
    padding: 80px 40px;
    margin-top: -100px;
    margin-left: 2px;
}
.proBox .seeds{
	margin-top: -70px;
}
.proBox h3 {
	margin-top: 5px;
}
.proBox p {
    font-size: 14px;
    padding: 0 70px;
}
.x5{
	text-align:right;
	font-size: 16px;
	padding: 32px 30px;
}

.proBox .btn-success{
	font-size: 17px;
	margin-right:10px;
	margin-bottom: 20px;
}
.proBox .btn-success:focus{
	outline: none;
}

.productSec .p2{
   text-align:right;
   padding: 32px 30px;
}
.productSec .p3{
  text-align:right;
  font-size: 16px;
  padding: 32px 30px;
}
.productSec .p4{
  color: #11B3DE;
}
.productSec .p5{
	color: #11B3DE;
}
.productSec .p6{
	color: #11B3DE;
}
.productSec .bs{
	font-weight: bold;
}
.productSec .btn-lg{
	margin-top: 2px;
	border-radius: 35px;
}
.proBox .s1{
  padding: 0px 30px;
  margin-right: 170px;
  width: 145px;
  height: 13px;
  margin-top: -60px;
}
.proBox .s2{
	padding: 0px 30px;
    margin-right: 170px;
    width: 145px;
    height: 13px;
    margin-top: -60px;
}
.proBox .s3{
	padding: 0px 30px;
	margin-right: 170px;
	width: 145px;
    height: 13px;
    margin-top: -60px;
}
/* BestSeller Section End*/

/*counter button css start*/
#myform {
    text-align: center;
    margin-top: 75px;
    float: left;
}
#myform .btn-success{
	border-radius: 15px;
	margin-top: 15px;
}
#myform .btn-success:focus{
	outline: none;
}
.modal-footer .btn-success{
	border-radius: 15px;
}
.modal-footer .btn-success:focus{
	outline: none;
}
.qty {
    width: 40px;
    height: 25px;
    text-align: center;
}
input.qtyplus { 
	width:25px;
	height:25px;
    color: #fff;
    background-color: #5cb85c;
    border-color: #4cae4c;
    border:none;
}
input.qtyminus {
	width:25px;
	height:25px;
    color: #fff;
    background-color: #5cb85c;
    border-color: #4cae4c;
    border:none;
}
/*counter button css end*/

/* Popular Section Start*/
.popularSec {
    padding: 20px 0;
}
.popularSec .popular{
    padding: 103px 52px;
    margin-top: -133px;
    margin-left: 2px;
}

.popBox {
    border: 1px solid #D7DCD3;
    border-radius: 0 30px;
    text-align: center;
    transition: 1s;
    height: 600px;
}
.popBox:hover {
    border: 1px solid #D7DCD3;
    box-shadow: 0 10px 10px rgba(0,0,0,0.3);
    transition: 1s;
}
.popBox img {
    padding: 30px;
    padding-top: 5px;
    
}
.popBox h3 {
    font-weight: 600;
    margin-top: 0;
}
.popBox p {
    font-size: 14px;
    padding: 0 70px;
}
.popBox .img8{
	width: 28%;
	height: auto;
	margin-top: -100px;
    margin-left: 230px;
}
.popBox .hearts{
	width: 110px;
    height: 86px;
    margin: -64px 140px;
}
.popBox .percent{
	width: 35%;
	height: auto;
	margin-top: 10px;
}
.popBox .img-responsive{
	margin-left: 5px;
}
.popBox .jumbotron{
	 width: 290px;
	 height: 160px;
	 background-size: 100%;
	 background-color: #4B4A4A;
	 margin-left: 30px;
     margin-top: -103px;
}
.t1{
	color: white;
    margin: 7px;
    margin-left: 6px;
}
.t2{
	color: white;
    padding-right: 10px;
    margin-top: -24px;
    margin-left: 4px;
}

.t6{
	color: white;
	padding-right: 10px;
	margin-top: -20px;
}
.x8{
	color: white;
	margin-left: 30px;
	margin-top: -16px;
}
.popularSec .v1{
	font-weight: bold;
}
.popularSec .btn-lg{
	margin-top: 35px;
	border-radius: 40px;
}
.jumbotron .s4{
    padding: 0px 43px;
    height: 15px;
    margin-left: -74px;
}
.jumbotron .s5{
	padding: 0px 20px;
    width: 130px;
    height: 15px;
    margin-left: -74px;
}
.jumbotron .s6{
	padding: 0px 20px;
	width: 130px;
	height: 15px;
    margin-right:35px;
}
/* Popular Section End*/
/*end of product page styling*/

/*start of aboutUs styling*/
.bannerSection .carousel-caption .aboutUsHeading{
	font-weight: bold;
}
.bannerSection .carousel-caption .aboutusParagraph{
	font-size: 17px;
	margin-bottom: 174px;
}
.bannerSection .carousel-inner img{
	height: 540px;
	width: 100%;
}
/*end of header ection*/
.history .well-lg{
	background-color:#0BB9D8;
	margin-top: 40px;
	height: 100px;
}
.history .d1{
	font-weight: bold;
}
.p1{
	color: white;
	text-align: center;
	font-size: 20px;
}
.st{
	text-align: center;
	margin-top: 50px;
	color: lightgreen;
	font-weight: bold;

}
.st1{
	text-align: center;
	font-size: 20px;
}
.st3{
	text-align: center;
	margin-top: 40px;
	color: lightgreen;
	font-weight: bold;

}
.st4{
	text-align: center;
	font-size: 20px;
}

/* history section end*/

/*OurMission section start*/

.OurMission .well-lg{
	  background-color: #CED1D1;
	  height: 300px;
	  width: 1140px;

}
.OurMission h2{
	 font-weight: bold;
	 padding-left: 20px;
}
.OurMission p{
	 font-size: 17px;
	 padding-left: 20px;
}
.OurMission .col-lg-6 img{
	margin-top: 25px;
	width: 400px;
	height: 250px;
	margin-left: 100px;
}
.OurMission .mission{
	font-weight: bold;
}
/*Our Mission section end*/

/*Our Family section end*/
.OurFamily img{
	margin-top: 60px;
}
.OurFamily .r1{
	 margin: 290px 0px;
}
.OurFamily .r2{
	width: 295px;
	height: 265px;
	margin: 640px 0px;
}
.OurFamily .d2{
	font-weight: bold;
}
.OurFamily .p2{
	margin: -510px 390px;
}
.Ourfamily .p3{
	margin: -850px 390px;
}
/*Our Family section end*/
/*end of about us styling*/

/*common footer for all 4 pages*/
footer .col-sm-4 h2{
	margin-left: 70px;
	font-weight: bold;
}
footer .col-sm-4 a{
	margin-left: 70px;
	color: black;
}
footer .col-sm-4 p{
	margin-left: 70px;
}

footer .well-sm{
	background-color: black;
}
footer .well-sm p{
	text-align: center;
	color: white;